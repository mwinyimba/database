<?php
declare(strict_types=1);

/**
 * @deprecated 4.0.0 Use {@link \Cake\Command\Command} instead.
 */

class_alias(
    'Cake\Command\Command',
    'Cake\Console\Command'
);
